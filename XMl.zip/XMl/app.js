// --- Mock Data ---
const matchesData = [
  { group: "Grupo A", team1: "México", code1: "mx", team2: "Sudáfrica", code2: "za", date: "11 JUN", time: "21:00" },
  { group: "Grupo A", team1: "Corea del Sur", code1: "kr", team2: "Chequia", code2: "cz", date: "12 JUN", time: "4:00" },
  { group: "Grupo B", team1: "Canadá", code1: "ca", team2: "Bosnia", code2: "ba", date: "12 JUN", time: "21:00" },
  { group: "Grupo D", team1: "EE.UU.", code1: "us", team2: "Paraguay", code2: "py", date: "13 JUN", time: "3:00" },
  { group: "Grupo B", team1: "Catar", code1: "qa", team2: "Suiza", code2: "ch", date: "13 JUN", time: "21:00" },
  { group: "Grupo C", team1: "Brasil", code1: "br", team2: "Marruecos", code2: "ma", date: "14 JUN", time: "0:00" },
  { group: "Grupo E", team1: "España", code1: "es", team2: "Alemania", code2: "de", date: "15 JUN", time: "21:00" },
  { group: "Grupo F", team1: "Argentina", code1: "ar", team2: "Francia", code2: "fr", date: "16 JUN", time: "21:00" }
];

const leaderboardData = [
  { name: "Carlos Pérez", f1: 85, f2: 40, live: 12, total: 137 },
  { name: "Ana Martínez", f1: 80, f2: 45, live: 8, total: 133 },
  { name: "Juan Gómez", f1: 75, f2: 50, live: 4, total: 129 },
  { name: "Laura Sánchez", f1: 78, f2: 38, live: 6, total: 122 },
  { name: "David Ruiz", f1: 70, f2: 40, live: 10, total: 120 }
];

const prizesData = [
  { id: "p1", title: "Campeón Absoluto", amount: "340 €", winner: null },
  { id: "p2", title: "Subcampeón", amount: "170 €", winner: null },
  { id: "p3", title: "Tercer Puesto", amount: "60 €", winner: null },
  { id: "p4", title: "Maestro de Grupos", amount: "60 €", winner: "Carlos Pérez" },
  { id: "p5", title: "Arquitecto del Cuadro", amount: "60 €", winner: null },
  { id: "p6", title: "Rey del Directo", amount: "60 €", winner: null }
];

// --- Translations ---
const translations = {
  es: {
    nav_title: "MUNDIAL 2026",
    nav_login: "Entrar / Registro",
    title: "LA PORRA DEL MUNDIAL 2026",
    subtitle: "EL LIBRO MAESTRO - Reglamento oficial",
    tab_rules: "Reglamento",
    tab_matches: "Partidos",
    tab_leaderboard: "Clasificación en Directo",
    tab_prizes: "Premios Actuales",
    matches_title: "Partidos · Fase de grupos",
    matches_reminder: "Activar recordatorios",
    leaderboard_title: "Clasificación en Directo",
    lb_player: "JUGADOR",
    lb_f1: "FASE 1",
    lb_f2: "FASE 2",
    lb_live: "DIRECTO",
    lb_total: "TOTAL",
    prizes_live_title: "Bote y Premios Actualizados",
    prizes_total: "BOTE TOTAL RECAUDADO",
    prizes_players: "25 Jugadores inscritos",
    auth_title: "Registro / Acceso",
    auth_desc: "Únete a la porra oficial. Recibirás recordatorios de partidos por WhatsApp/SMS.",
    auth_name: "Nombre completo",
    auth_email: "Correo electrónico",
    auth_phone: "Teléfono (WhatsApp)",
    auth_submit: "Inscribirse en la Porra",
    footer: "© 2026 La Porra del Mundial. Todos los derechos reservados.",
    sections: [
      {
        id: "intro", icon: "fa-book-open", title: "Reglamento oficial de la competición",
        content: "<p>La presente normativa regula el funcionamiento íntegro de La Porra del Mundial 2026, así como el sistema de inscripción, puntuación, clasificación, desempates y reparto de premios aplicable a todos los participantes.</p><p class='gold-text'>La participación en el juego implica la aceptación total de estas normas.</p>"
      },
      {
        id: "inscripcion", icon: "fa-users", title: "1. Inscripción y fondo económico",
        content: "<ul><li><span class='highlight'>Número de participantes:</span> 25 jugadores.</li><li><span class='highlight'>Cuota de inscripción:</span> 30 € por jugador.</li><li><span class='highlight'>Gastos de gestión:</span> 2 € adicionales por jugador.</li><li><span class='highlight'>Importe total del bote:</span> <span class='gold-text'>750 €</span>.</li><li><span class='highlight'>Forma de pago:</span> Bizum al administrador.</li><li><span class='highlight'>Concepto del pago:</span> PORRA + Nombre.</li></ul><p>Los 30 € de inscripción de cada participante integran exclusivamente el bote de premios.</p>"
      }
    ]
  },
  va: {
    nav_title: "MUNDIAL 2026",
    nav_login: "Entrar / Registre",
    title: "LA PORRA DEL MUNDIAL 2026",
    subtitle: "EL LLIBRE MESTRE - Reglament oficial",
    tab_rules: "Reglament",
    tab_matches: "Partits",
    tab_leaderboard: "Classificació en Directe",
    tab_prizes: "Premis Actuals",
    matches_title: "Partits · Fase de grups",
    matches_reminder: "Activar recordatoris",
    leaderboard_title: "Classificació en Directe",
    lb_player: "JUGADOR",
    lb_f1: "FASE 1",
    lb_f2: "FASE 2",
    lb_live: "DIRECTE",
    lb_total: "TOTAL",
    prizes_live_title: "Pot i Premis Actualitzats",
    prizes_total: "POT TOTAL RECAPTAT",
    prizes_players: "25 Jugadors inscrits",
    auth_title: "Registre / Accés",
    auth_desc: "Unix-te a la porra oficial. Rebràs recordatoris de partits per WhatsApp/SMS.",
    auth_name: "Nom complet",
    auth_email: "Correu electrònic",
    auth_phone: "Telèfon (WhatsApp)",
    auth_submit: "Inscriure's a la Porra",
    footer: "© 2026 La Porra del Mundial. Tots els drets reservats.",
    sections: [
      {
        id: "intro", icon: "fa-book-open", title: "Reglament oficial de la competició",
        content: "<p>La present normativa regula el funcionament íntegre de La Porra del Mundial 2026...</p>"
      }
    ]
  },
  en: {
    nav_title: "WORLD CUP 2026",
    nav_login: "Login / Register",
    title: "WORLD CUP 2026 SWEEPSTAKES",
    subtitle: "THE MASTER BOOK - Official Rules",
    tab_rules: "Rules",
    tab_matches: "Matches",
    tab_leaderboard: "Live Leaderboard",
    tab_prizes: "Current Prizes",
    matches_title: "Matches · Group Stage",
    matches_reminder: "Enable reminders",
    leaderboard_title: "Live Leaderboard",
    lb_player: "PLAYER",
    lb_f1: "PHASE 1",
    lb_f2: "PHASE 2",
    lb_live: "LIVE",
    lb_total: "TOTAL",
    prizes_live_title: "Live Pot and Prizes",
    prizes_total: "TOTAL POT COLLECTED",
    prizes_players: "25 Registered Players",
    auth_title: "Register / Login",
    auth_desc: "Join the official sweepstakes. You will receive match reminders via WhatsApp/SMS.",
    auth_name: "Full Name",
    auth_email: "Email address",
    auth_phone: "Phone (WhatsApp)",
    auth_submit: "Join the Sweepstakes",
    footer: "© 2026 World Cup Sweepstakes. All rights reserved.",
    sections: [
      {
        id: "intro", icon: "fa-book-open", title: "Official Competition Rules",
        content: "<p>These regulations govern the entire operation of the 2026 World Cup Sweepstakes...</p>"
      }
    ]
  }
};

const ruleSectionsEs = [
    { id: "intro", icon: "fa-book-open", title: "Reglamento oficial de la competición", content: "<p>La presente normativa regula el funcionamiento íntegro de La Porra del Mundial 2026. Todos los participantes deben acatar estas reglas para garantizar el buen funcionamiento del juego.</p>" },
    { id: "inscripcion", icon: "fa-users", title: "1. Inscripción y fondo económico", content: "<ul><li><span class='highlight'>Número de participantes:</span> 25 jugadores.</li><li><span class='highlight'>Cuota:</span> 30 €.</li><li><span class='highlight'>Método de pago:</span> Bizum al número del administrador.</li></ul><p>Los 30 € de inscripción de cada participante integran exclusivamente el bote de premios.</p>" },
    { id: "premios", icon: "fa-money-bill-wave", title: "2. Estructura de premios", content: "<p><span class='highlight'>Fondo total:</span> <span class='gold-text'>750 €</span></p><ul><li>Campeón Absoluto: 340 €</li><li>Subcampeón: 170 €</li><li>Tercer Puesto: 60 €</li><li>Premios Menores (Grupos, Cuadro, Directo): 60 € c/u</li></ul>" },
    { id: "fase1", icon: "fa-1", title: "3. Fase 1: Fase de Grupos", content: "<p>Los jugadores deberán pronosticar los resultados exactos de los partidos de la fase de grupos.</p><p><span class='highlight'>Puntuación:</span></p><ul><li>Acertar resultado exacto (ej. 2-1): <span class='gold-text'>3 puntos</span>.</li><li>Acertar tendencia (ganador o empate): <span class='gold-text'>1 punto</span>.</li></ul>" },
    { id: "fase2", icon: "fa-2", title: "4. Fase 2: Eliminatorias", content: "<p>A partir de octavos de final, se pronosticarán los equipos que avanzan de ronda. Puntuación progresiva según la fase de eliminatoria.</p>" },
    { id: "fase3", icon: "fa-trophy", title: "5. Fase 3: La Gran Final", content: "<p>Se debe pronosticar el Campeón del Mundo y el resultado exacto de la final. Premio especial al acierto pleno.</p>" }
];
translations.es.sections = ruleSectionsEs;
translations.va.sections = ruleSectionsEs;
translations.en.sections = ruleSectionsEs;

let currentLang = 'es';

document.addEventListener('DOMContentLoaded', () => {
  setupLanguageToggle();
  setupTabs();
  setupModal();
  renderAll();
});

function renderAll() {
  renderStaticText();
  renderRules();
  renderMatches();
  renderLeaderboard();
  renderPrizes();
}

function setupLanguageToggle() {
  const buttons = document.querySelectorAll('.lang-btn');
  buttons.forEach(btn => {
    btn.addEventListener('click', (e) => {
      buttons.forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');
      currentLang = e.target.getAttribute('data-lang');
      renderAll();
    });
  });
}

function renderStaticText() {
  const t = translations[currentLang];
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (t[key]) {
      el.innerHTML = t[key];
    }
  });
  
  document.getElementById('title').textContent = t.title;
  document.getElementById('title').setAttribute('data-text', t.title);
  document.getElementById('subtitle').textContent = t.subtitle;
  document.getElementById('footer-text').textContent = t.footer;
  document.documentElement.lang = currentLang;
}

function renderRules() {
  const t = translations[currentLang];
  const container = document.getElementById('content-sections');
  container.innerHTML = '';

  t.sections.forEach((section, index) => {
    const card = document.createElement('div');
    card.className = 'section-card';
    if(index === 0) card.classList.add('active');

    const header = document.createElement('div');
    header.className = 'section-header';
    header.innerHTML = `<h2><i class="fa-solid ${section.icon} icon"></i> ${section.title}</h2><i class="fa-solid fa-chevron-down toggle-icon"></i>`;

    const content = document.createElement('div');
    content.className = 'section-content';
    content.innerHTML = section.content;

    header.addEventListener('click', () => {
      card.classList.toggle('active');
      content.style.maxHeight = card.classList.contains('active') ? content.scrollHeight + "px" : "0";
    });

    card.appendChild(header);
    card.appendChild(content);
    container.appendChild(card);

    if(card.classList.contains('active')) {
      setTimeout(() => content.style.maxHeight = content.scrollHeight + "px", 100);
    }
  });
}

function renderMatches() {
  const container = document.getElementById('matches-grid');
  container.innerHTML = '';
  matchesData.forEach(m => {
    const card = document.createElement('div');
    card.className = 'match-card';
    card.innerHTML = `
      <div class="match-info">
        <div class="match-group">${m.group}</div>
        <div class="teams-container">
          <div class="team">
            <img src="https://flagcdn.com/w40/${m.code1}.png" class="flag-img" alt="${m.team1}">
            <span class="team-name">${m.team1}</span>
          </div>
          <div class="team-vs">VS</div>
          <div class="team">
            <span class="team-name">${m.team2}</span>
            <img src="https://flagcdn.com/w40/${m.code2}.png" class="flag-img" alt="${m.team2}">
          </div>
        </div>
      </div>
      <div class="match-time">
        <div class="date"><i class="fa-regular fa-calendar"></i> ${m.date}</div>
        <div class="time"><i class="fa-regular fa-clock"></i> ${m.time}</div>
      </div>
    `;
    container.appendChild(card);
  });
}

function renderLeaderboard() {
  const tbody = document.getElementById('leaderboard-body');
  tbody.innerHTML = '';
  const sorted = [...leaderboardData].sort((a,b) => b.total - a.total);
  
  sorted.forEach((player, index) => {
    const pos = index + 1;
    let posClass = '';
    if(pos === 1) posClass = 'pos-1';
    if(pos === 2) posClass = 'pos-2';
    if(pos === 3) posClass = 'pos-3';
    
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="${posClass}">${pos}</td>
      <td class="player-name">${player.name}</td>
      <td>${player.f1}</td>
      <td>${player.f2}</td>
      <td class="live-score">${player.live > 0 ? '+'+player.live : player.live}</td>
      <td class="total-score">${player.total}</td>
    `;
    tbody.appendChild(tr);
  });
}

function renderPrizes() {
  const container = document.getElementById('live-prizes-grid');
  container.innerHTML = '';
  prizesData.forEach(p => {
    const isWon = p.winner !== null;
    const card = document.createElement('div');
    card.className = `prize-card ${isWon ? 'won' : ''}`;
    
    card.innerHTML = `
      <h3>${p.title}</h3>
      <div class="prize-amount">${p.amount}</div>
      <div class="winner-info">
        ${isWon ? `<span class="won-badge">GANADO</span> <span>${p.winner}</span>` : `<i class="fa-solid fa-hourglass-half"></i> En juego`}
      </div>
    `;
    container.appendChild(card);
  });
}

function setupTabs() {
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));
      
      btn.classList.add('active');
      const targetId = btn.getAttribute('data-tab');
      document.getElementById(`tab-${targetId}`).classList.add('active');
    });
  });
}

function setupModal() {
  const modal = document.getElementById('auth-modal');
  const loginBtn = document.getElementById('login-btn');
  const closeBtn = document.querySelector('.close-modal');
  const form = document.getElementById('auth-form');

  loginBtn.addEventListener('click', () => {
    modal.classList.add('show');
  });

  closeBtn.addEventListener('click', () => {
    modal.classList.remove('show');
  });

  window.addEventListener('click', (e) => {
    if (e.target === modal) {
      modal.classList.remove('show');
    }
  });
  
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const content = document.querySelector('.modal-content');
    content.innerHTML = `
      <span class="close-modal">&times;</span>
      <div style="text-align: center; padding: 1rem 0;">
        <h2 style="color: #fff; margin-bottom: 1rem;">Paso Final: Pago</h2>
        <p style="color: #9aa0a6; margin-bottom: 2rem;">Para completar tu inscripción, debes abonar la cuota de 30€.</p>
        
        <div class="bizum-card">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/22/Bizum.svg/2560px-Bizum.svg.png" alt="Bizum" style="height: 40px; margin-bottom: 1rem;">
          <p style="font-size: 1.5rem; color: #fff; font-weight: bold; margin-bottom: 1rem;">30,00 €</p>
          <button class="bizum-btn" id="bizum-pay-btn">
            Pagar con Bizum
          </button>
        </div>
      </div>
    `;
    
    // Re-attach close listeners for the newly injected close buttons
    document.querySelector('.close-modal').addEventListener('click', () => modal.classList.remove('show'));
    
    document.getElementById('bizum-pay-btn').addEventListener('click', () => {
      const bizumCard = document.querySelector('.bizum-card');
      bizumCard.innerHTML = `
        <div class="loader-container">
          <div class="spinner"></div>
          <p style="margin-top: 1rem; color: #00ff88; font-weight: 500;">Conectando con tu banco...</p>
        </div>
      `;

      setTimeout(() => {
        content.innerHTML = `
          <span class="close-modal">&times;</span>
          <div style="text-align: center; padding: 2rem 0;">
            <i class="fa-solid fa-circle-check" style="font-size: 4.5rem; color: #00ff88; margin-bottom: 1.5rem; text-shadow: 0 0 20px rgba(0,255,136,0.4);"></i>
            <h2 style="color: #00ff88; margin-bottom: 0.5rem;">¡Pago Completado!</h2>
            <p style="color: #9aa0a6;">Estás oficialmente inscrito en La Porra del Mundial 2026. ¡Mucha suerte!</p>
            <button class="submit-btn" id="close-success-btn" style="margin-top: 2rem;">Acceder a mi panel</button>
          </div>
        `;
        
        document.querySelector('.close-modal').addEventListener('click', () => modal.classList.remove('show'));
        document.getElementById('close-success-btn').addEventListener('click', () => {
          modal.classList.remove('show');
          document.getElementById('login-btn').innerHTML = '<i class="fa-solid fa-user-check"></i> <span>Mi Panel</span>';
          document.getElementById('login-btn').style.background = 'var(--accent-neon)';
        });
      }, 2500); // Simulate Bizum processing time
    });
  });
}
